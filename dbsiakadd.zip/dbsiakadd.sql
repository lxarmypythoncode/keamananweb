-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 11 Des 2023 pada 00.24
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbsiakad`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbldosen`
--

CREATE TABLE `tbldosen` (
  `nidn` char(7) NOT NULL,
  `nama_lengkap` varchar(35) NOT NULL,
  `pendidikan` varchar(35) NOT NULL,
  `alamat` text NOT NULL,
  `jnskel` varchar(1) NOT NULL,
  `foto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbldosen`
--

INSERT INTO `tbldosen` (`nidn`, `nama_lengkap`, `pendidikan`, `alamat`, `jnskel`, `foto`) VALUES
('20TF025', 'anam', 's1 TF', 'telagawaru', 'L', 'comment_1.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tblmahasiswa`
--

CREATE TABLE `tblmahasiswa` (
  `nim` char(7) NOT NULL,
  `nama_mhs` varchar(35) NOT NULL,
  `prodi` text NOT NULL,
  `semester` int(2) NOT NULL,
  `alamat` text NOT NULL,
  `jnskel` varchar(1) NOT NULL,
  `foto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tblmahasiswa`
--

INSERT INTO `tblmahasiswa` (`nim`, `nama_mhs`, `prodi`, `semester`, `alamat`, `jnskel`, `foto`) VALUES
('20TF011', 'jam', 'Sistem Informasi', 7, 'kuburan', 'P', '444.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tblmatakuliah`
--

CREATE TABLE `tblmatakuliah` (
  `kdmk` char(5) NOT NULL,
  `nama_mk` varchar(50) NOT NULL,
  `sks` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tblmatakuliah`
--

INSERT INTO `tblmatakuliah` (`kdmk`, `nama_mk`, `sks`) VALUES
('011', 'Forensik', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `email` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `level` varchar(50) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`email`, `password`, `level`, `nama_lengkap`) VALUES
('admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'admin', 'admin'),
('alipandu@gmail.com', '8acf7115033fa7bbfebe4b9b726ab374', 'mahasiswa', 'alipandu'),
('fira@gmail.com', 'd57d8d5422365e4295153b987f907c5e', 'dosen', 'firaria');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbldosen`
--
ALTER TABLE `tbldosen`
  ADD PRIMARY KEY (`nidn`);

--
-- Indeks untuk tabel `tblmahasiswa`
--
ALTER TABLE `tblmahasiswa`
  ADD PRIMARY KEY (`nim`);

--
-- Indeks untuk tabel `tblmatakuliah`
--
ALTER TABLE `tblmatakuliah`
  ADD PRIMARY KEY (`kdmk`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
